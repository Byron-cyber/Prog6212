# Part 2 - Suggested commit plan (20+ meaningful commits)

The brief requires **at least 20 meaningful commits made with your own GitHub account**.
Commit as you go instead of all at once. Because the project is already written, a good way to get a
genuine history is to **add the files in logical stages** (copy the files in, then commit after each stage),
running `dotnet build` as you go. Suggested order:

| # | Commit message | What to add |
|---|----------------|-------------|
| 1 | `Create Part 2 branch and ASP.NET Core Web API project` | `RaceDay.sln`, `RaceDay.Api/RaceDay.Api.csproj`, `.gitignore` |
| 2 | `Add NuGet packages for EF Core, SQL Server and Swagger` | package references |
| 3 | `Add constants for roles and status values` | `Common/Constants.cs` |
| 4 | `Add Role and User models` | `Models/Role.cs`, `Models/User.cs` |
| 5 | `Add Event and Category models` | `Models/Event.cs`, `Models/Category.cs` |
| 6 | `Add Enrolment and Result models` | `Models/Enrolment.cs`, `Models/Result.cs` |
| 7 | `Add ApplicationDbContext matching the Part 1 ERD` | `Data/ApplicationDbContext.cs` |
| 8 | `Add connection string and database registration` | `appsettings.json`, `Program.cs` |
| 9 | `Add initial EF Core migration` | `dotnet ef migrations add InitialCreate` output |
| 10 | `Add DTOs, shared error shape and mappers` | `Dtos/`, `Common/` |
| 11 | `Configure cookie session authentication` | auth section of `Program.cs` |
| 12 | `Add AuthController: register, login, logout with hashed passwords` | `Controllers/AuthController.cs` |
| 13 | `Add UsersController for profile view and update` | `Controllers/UsersController.cs` |
| 14 | `Add EventsController with organiser-only management` | `Controllers/EventsController.cs` |
| 15 | `Add CategoriesController` | `Controllers/CategoriesController.cs` |
| 16 | `Add EnrolmentsController` | `Controllers/EnrolmentsController.cs` |
| 17 | `Add ResultsController` | `Controllers/ResultsController.cs` |
| 18 | `Add Swagger XML documentation and health endpoint` | `HealthController.cs`, Swagger setup |
| 19 | `Add demo data seeder` | `Data/DbSeeder.cs` |
| 20 | `Add xUnit test project and test factory` | `RaceDay.Tests/RaceDay.Tests.csproj`, `ApiFactory.cs` |
| 21 | `Add authentication and role-access tests` | `AuthTests.cs`, `RoleAccessTests.cs` |
| 22 | `Add event and category tests` | `EventTests.cs`, `CategoryTests.cs` |
| 23 | `Add enrolment and result tests` | `EnrolmentTests.cs`, `ResultTests.cs` |
| 24 | `Add GitHub Actions workflow to build and test` | `.github/workflows/dotnet.yml` |
| 25 | `Add README with setup, roles and CI screenshot` | `README.md`, screenshot |

Example commands for one stage:

```powershell
git checkout -b part2-api
git add RaceDay.Api/Models/Role.cs RaceDay.Api/Models/User.cs
git commit -m "Add Role and User models"
git push -u origin part2-api
```
