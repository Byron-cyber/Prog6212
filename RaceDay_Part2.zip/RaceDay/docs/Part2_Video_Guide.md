# Part 2 - What to show in your YouTube video

Record an **unlisted** YouTube video (about 8-12 minutes). Suggested running order:

1. **Intro (30s)** - what RaceDay is, the two roles (Organiser, Participant).
2. **Code structure (2 min)** - open the solution and walk through the folders:
   - `Models/` - one class per table in your Part 1 ERD.
   - `Data/ApplicationDbContext.cs` - the Code-First model (keys, unique indexes, check constraints, cascade delete).
   - `Controllers/` - one controller per area of the endpoint plan.
   - `Dtos/` - why password hashes never leave the API.
   - `Program.cs` - Swagger, database, cookie authentication.
3. **Run it (1 min)** - `dotnet run`, Swagger opens at `/swagger`. Show the tables in SSMS.
4. **Authentication demo in Swagger (3 min)**
   - Register an Organiser and a Participant (show that the `role` is validated).
   - Log in as the Organiser. Call `GET /api/users/me`.
   - Show the password is hashed in the `Users` table.
   - Log out, then show `GET /api/users/me` gives 401.
5. **Endpoints demo (3 min)**
   - Organiser: create event, add categories, view enrolments, capture a result.
   - Log in as the Participant: enrol in a category, view `enrolments/me` and `results/me`.
   - Show a Participant trying an Organiser endpoint (403).
6. **Unit tests (2 min)** - run `dotnet test`, then explain `ApiFactory` (in-memory database) and a few tests:
   registration/login, organiser event management, role rejection (401/403), enrolment recorded correctly.
7. **CI/CD (30s)** - show the green GitHub Actions run.

Key sentences to be ready to say:
- "Authentication uses a cookie session. On login the user's id and role are stored as claims in the cookie."
- "Passwords are hashed with ASP.NET's `PasswordHasher` (PBKDF2). The plain password is never stored."
- "Role checks use `[Authorize(Roles = ...)]`, and ownership checks make sure an organiser can only change their own events."
