using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Common;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;
using RaceDay.Api.Models;

namespace RaceDay.Api.Controllers;

/// <summary>Browse events (everyone) and manage events (Organisers, own events only).</summary>
[Tags("Events")]
public class EventsController : ApiControllerBase
{
    private readonly ApplicationDbContext _db;

    public EventsController(ApplicationDbContext db) => _db = db;

    /// <summary>List events that are open to the public (Draft events are never listed).</summary>
    /// <remarks>
    /// Optional filters: city, province, dateFrom, dateTo (YYYY-MM-DD), status (Published, Cancelled, Completed).
    /// Pagination: page (default 1) and pageSize (default 20, max 100). The total number of matches is returned
    /// in the X-Total-Count response header.
    /// </remarks>
    /// <returns>200 with an array of event summaries ordered by date.</returns>
    [HttpGet("events")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(List<EventDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> GetEvents(
        [FromQuery] string? city, [FromQuery] string? province,
        [FromQuery] DateOnly? dateFrom, [FromQuery] DateOnly? dateTo,
        [FromQuery] string? status, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        if (page < 1) return BadRequestError("page must be 1 or more.", "page");
        if (pageSize < 1 || pageSize > 100) return BadRequestError("pageSize must be between 1 and 100.", "pageSize");

        var query = _db.Events.AsNoTracking().Where(e => e.Status != EventStatuses.Draft);

        if (!string.IsNullOrWhiteSpace(status))
        {
            var match = EventStatuses.All.FirstOrDefault(s => string.Equals(s, status.Trim(), StringComparison.OrdinalIgnoreCase));
            if (match is null || match == EventStatuses.Draft)
                return BadRequestError("status must be Published, Cancelled or Completed.", "status");
            query = query.Where(e => e.Status == match);
        }
        if (!string.IsNullOrWhiteSpace(city))
        {
            var c = city.Trim().ToLower();
            query = query.Where(e => e.City.ToLower() == c);
        }
        if (!string.IsNullOrWhiteSpace(province))
        {
            var p = province.Trim().ToLower();
            query = query.Where(e => e.Province.ToLower() == p);
        }
        if (dateFrom is not null) query = query.Where(e => e.EventDate >= dateFrom);
        if (dateTo is not null) query = query.Where(e => e.EventDate <= dateTo);

        var total = await query.CountAsync();
        var events = await query
            .OrderBy(e => e.EventDate).ThenBy(e => e.EventId)
            .Skip((page - 1) * pageSize).Take(pageSize)
            .ToListAsync();

        Response.Headers["X-Total-Count"] = total.ToString();
        return Ok(events.Select(e => e.ToDto()).ToList());
    }

    /// <summary>Get the full details of one event, including its categories.</summary>
    /// <remarks>Draft events are only visible to the Organiser who owns them.</remarks>
    /// <returns>200 with the event and its categories, 404 if it does not exist (or is someone else's draft).</returns>
    [HttpGet("events/{id:int}")]
    [AllowAnonymous]
    [ProducesResponseType(typeof(EventDetailDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetEvent(int id)
    {
        var ev = await _db.Events.AsNoTracking().Include(e => e.Categories)
            .SingleOrDefaultAsync(e => e.EventId == id);
        if (ev is null || !CanSee(ev)) return NotFoundError("Event not found.");
        return Ok(ev.ToDetailDto());
    }

    /// <summary>List every event created by the logged-in Organiser (including drafts).</summary>
    /// <returns>200 with an array of events, 401 if not logged in, 403 for Participants.</returns>
    [HttpGet("events/my")]
    [Authorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(List<EventDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> GetMyEvents()
    {
        var me = CurrentUserId;
        var events = await _db.Events.AsNoTracking()
            .Where(e => e.OrganiserId == me)
            .OrderBy(e => e.EventDate).ThenBy(e => e.EventId)
            .ToListAsync();
        return Ok(events.Select(e => e.ToDto()).ToList());
    }

    /// <summary>Create a new event (Organisers only). The logged-in Organiser becomes its owner.</summary>
    /// <remarks>
    /// Expects title, eventDate (YYYY-MM-DD), location, city and province. Optional: description,
    /// startTime (HH:mm), status ("Draft" or "Published", default Draft), maxParticipants, imageUrl.
    /// </remarks>
    /// <returns>201 with the created event, 400 for invalid data, 401 if not logged in, 403 for Participants.</returns>
    [HttpPost("events")]
    [Authorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status201Created)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    public async Task<IActionResult> CreateEvent([FromBody] CreateEventRequest request)
    {
        var status = EventStatuses.All.FirstOrDefault(s =>
            string.Equals(s, request.Status?.Trim(), StringComparison.OrdinalIgnoreCase));
        if (status is not (EventStatuses.Draft or EventStatuses.Published))
            return BadRequestError("status must be 'Draft' or 'Published' when creating an event.", "status");

        var ev = new Event
        {
            OrganiserId = CurrentUserId,
            Title = request.Title.Trim(),
            Description = request.Description,
            EventDate = request.EventDate!.Value,
            StartTime = request.StartTime,
            Location = request.Location.Trim(),
            City = request.City.Trim(),
            Province = request.Province.Trim(),
            Status = status,
            MaxParticipants = request.MaxParticipants,
            ImageUrl = request.ImageUrl
        };
        _db.Events.Add(ev);
        await _db.SaveChangesAsync();

        return CreatedAtAction(nameof(GetEvent), new { id = ev.EventId }, ev.ToDto());
    }

    /// <summary>Update an event you own. Only the fields you send are changed.</summary>
    /// <returns>200 with the updated event, 400 for invalid data, 403 if it is not your event, 404 if it does not exist.</returns>
    [HttpPut("events/{id:int}")]
    [Authorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(EventDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> UpdateEvent(int id, [FromBody] UpdateEventRequest request)
    {
        var ev = await _db.Events.SingleOrDefaultAsync(e => e.EventId == id);
        if (ev is null) return NotFoundError("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenError("You can only change your own events.");

        if (request.Status is not null)
        {
            var status = EventStatuses.All.FirstOrDefault(s =>
                string.Equals(s, request.Status.Trim(), StringComparison.OrdinalIgnoreCase));
            if (status is null)
                return BadRequestError("status must be Draft, Published, Cancelled or Completed.", "status");
            ev.Status = status;
        }
        if (request.Title is not null)
        {
            if (string.IsNullOrWhiteSpace(request.Title)) return BadRequestError("title cannot be empty.", "title");
            ev.Title = request.Title.Trim();
        }
        if (request.Location is not null)
        {
            if (string.IsNullOrWhiteSpace(request.Location)) return BadRequestError("location cannot be empty.", "location");
            ev.Location = request.Location.Trim();
        }
        if (request.City is not null)
        {
            if (string.IsNullOrWhiteSpace(request.City)) return BadRequestError("city cannot be empty.", "city");
            ev.City = request.City.Trim();
        }
        if (request.Province is not null)
        {
            if (string.IsNullOrWhiteSpace(request.Province)) return BadRequestError("province cannot be empty.", "province");
            ev.Province = request.Province.Trim();
        }
        if (request.Description is not null) ev.Description = request.Description;
        if (request.EventDate is not null) ev.EventDate = request.EventDate.Value;
        if (request.StartTime is not null) ev.StartTime = request.StartTime;
        if (request.MaxParticipants is not null) ev.MaxParticipants = request.MaxParticipants;
        if (request.ImageUrl is not null) ev.ImageUrl = request.ImageUrl;

        ev.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return Ok(ev.ToDto());
    }

    /// <summary>Cancel an event you own (its status becomes "Cancelled"; the data is kept).</summary>
    /// <returns>204 when cancelled, 403 if it is not your event, 404 if it does not exist.</returns>
    [HttpDelete("events/{id:int}")]
    [Authorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(StatusCodes.Status204NoContent)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var ev = await _db.Events.SingleOrDefaultAsync(e => e.EventId == id);
        if (ev is null) return NotFoundError("Event not found.");
        if (ev.OrganiserId != CurrentUserId) return ForbiddenError("You can only cancel your own events.");

        ev.Status = EventStatuses.Cancelled;
        ev.UpdatedAt = DateTime.UtcNow;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Draft events are only visible to their owner.</summary>
    private bool CanSee(Event ev) =>
        ev.Status != EventStatuses.Draft || (IsAuthenticated && ev.OrganiserId == CurrentUserId);
}
