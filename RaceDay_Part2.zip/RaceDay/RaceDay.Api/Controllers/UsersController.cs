using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDay.Api.Common;
using RaceDay.Api.Data;
using RaceDay.Api.Dtos;

namespace RaceDay.Api.Controllers;

/// <summary>View and update your own profile. Organisers can look up other users.</summary>
[Tags("User Profile")]
public class UsersController : ApiControllerBase
{
    private readonly ApplicationDbContext _db;

    public UsersController(ApplicationDbContext db) => _db = db;

    /// <summary>Get the profile of the logged-in user.</summary>
    /// <returns>200 with the profile (no password hash), 401 if not logged in.</returns>
    [HttpGet("users/me")]
    [Authorize]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> GetMyProfile()
    {
        var user = await _db.Users.Include(u => u.Role).SingleOrDefaultAsync(u => u.UserId == CurrentUserId);
        if (user is null) return NotFoundError("User not found.");
        return Ok(user.ToDto());
    }

    /// <summary>Update your own first name, last name, phone number and date of birth.</summary>
    /// <remarks>The email address and role cannot be changed.</remarks>
    /// <returns>200 with the updated profile, 400 for invalid data, 401 if not logged in.</returns>
    [HttpPut("users/me")]
    [Authorize]
    [ProducesResponseType(typeof(UserDto), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    public async Task<IActionResult> UpdateMyProfile([FromBody] UpdateProfileRequest request)
    {
        if (request.DateOfBirth is { } dob && dob > DateOnly.FromDateTime(DateTime.UtcNow))
            return BadRequestError("Date of birth cannot be in the future.", "dateOfBirth");

        var user = await _db.Users.Include(u => u.Role).SingleOrDefaultAsync(u => u.UserId == CurrentUserId);
        if (user is null) return NotFoundError("User not found.");

        user.FirstName = request.FirstName.Trim();
        user.LastName = request.LastName.Trim();
        user.PhoneNumber = request.PhoneNumber?.Trim();
        user.DateOfBirth = request.DateOfBirth;
        await _db.SaveChangesAsync();

        return Ok(user.ToDto());
    }

    /// <summary>Get limited public information about a user (Organisers only).</summary>
    /// <returns>200 with name, email and role, 403 for Participants, 404 if the user does not exist.</returns>
    [HttpGet("users/{id:int}")]
    [Authorize(Roles = RoleNames.Organiser)]
    [ProducesResponseType(typeof(UserSummaryDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ApiError), StatusCodes.Status404NotFound)]
    public async Task<IActionResult> GetUser(int id)
    {
        var user = await _db.Users.Include(u => u.Role).SingleOrDefaultAsync(u => u.UserId == id);
        if (user is null) return NotFoundError("User not found.");
        return Ok(user.ToSummary());
    }
}
