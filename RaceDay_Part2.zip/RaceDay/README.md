# RaceDay - Event Management Platform

**Portfolio of Evidence - Part 2: RESTful API Development**

RaceDay is a web-based event management system for South African road running, walking and cycling events.
This part is the ASP.NET Core Web API that powers the whole system. It follows the Part 1 plan
(`docs/RaceDay_ERD.md`, `docs/API_Endpoint_Plan.md`, `docs/RaceDay_Database.sql`) and is tested with xUnit and GitHub Actions.

- **Part 1 (planning + SQL):** `/docs`
- **Part 2 (this API):** `RaceDay.Api` (the API) and `RaceDay.Tests` (unit tests)

## The two roles

| Role | What they can do |
|------|------------------|
| **Organiser** | Create, update and cancel **their own** events, add/edit/delete categories, view all enrolments for their events, assign bib numbers, capture/correct/delete results |
| **Participant** | View events and categories, enrol in a category, view/cancel their own enrolments, view their own results |

Both roles can register, log in/out and view/update their own profile. Anonymous visitors can only browse
events, categories and published results. The role is chosen at registration and must be exactly
`Organiser` or `Participant` (validated server-side - it is never a free-text value or an id).

## Tech stack

ASP.NET Core Web API (.NET 10) - Entity Framework Core 10 (Code-First) - SQL Server - Swagger (Swashbuckle) -
cookie session authentication - xUnit + `WebApplicationFactory` - GitHub Actions

## Setup and run instructions

### 1. Prerequisites
- [.NET 10 SDK](https://dotnet.microsoft.com/download)
- SQL Server (e.g. SQL Server Express / Developer) and SSMS
- EF Core tools (once): `dotnet tool install --global dotnet-ef`

### 2. Connection string
Edit `RaceDay.Api/appsettings.json` so the server name matches yours:

```json
"ConnectionStrings": {
  "DefaultConnection": "Server=Byron\\Byron;Database=RaceDayDB;Trusted_Connection=True;TrustServerCertificate=True;"
}
```

> In JSON a backslash must be doubled (`\\`).
> If you already ran the Part 1 script `RaceDay_Database.sql`, drop that database first (in SSMS:
> `DROP DATABASE RaceDayDB;`) - EF Core creates the same schema itself and would clash with the existing tables.

### 3. Create the database (Code-First migration)
From the repository root:

```powershell
dotnet restore
dotnet ef migrations add InitialCreate --project RaceDay.Api
dotnet ef database update --project RaceDay.Api
```

(The API also creates/updates the database automatically when it starts.)

### 4. Run the API

```powershell
dotnet run --project RaceDay.Api
```

Swagger UI opens at **http://localhost:5274/swagger**. In Development the first run adds demo data
(same people and events as the Part 1 script). Every demo user has the password **`Password123!`**:

| Email | Role |
|-------|------|
| thabo.mokoena@raceday.co.za | Organiser |
| sarah.vdberg@capetowncycle.org | Organiser |
| lerato.dlamini@gmail.com | Participant |
| johan.pretorius@outlook.com | Participant |

### 5. Try it in Swagger
1. `POST /api/auth/login` with a demo account (or register your own).
2. Swagger UI keeps the session cookie, so every endpoint you try next is authenticated as that user.
3. Try an endpoint your role is not allowed to use to see the `403 Forbidden`; use `POST /api/auth/logout` to see `401 Unauthorized`.

### 6. Run the unit tests

```powershell
dotnet test
```

The tests use an in-memory database - no SQL Server needed.

## Authentication and sessions

- **Passwords** are hashed with ASP.NET's `PasswordHasher<User>` (PBKDF2 with a random salt). The plain password is never stored or returned.
- **Session:** `POST /api/auth/login` signs the user in with a cookie (`RaceDay.Session`, HttpOnly, 2-hour sliding expiry) holding the user id and role as claims. The browser sends it on every later request.
- **Role-based access:** `[Authorize(Roles = "Organiser")]` / `[Authorize(Roles = "Participant")]` / `[Authorize]`. Not logged in = `401`, wrong role = `403`.
- **Ownership:** an Organiser can only change their own events, categories, enrolments and results (`403` otherwise).

> Note on the Part 1 plan: the plan listed a JWT bearer token. The Part 2 brief asks for **session management**,
> so the implementation uses a cookie session instead. The login response still returns the user details and the session lifetime (`expiresIn`).

## Endpoints

All routes start with `/api`. Every endpoint is visible and testable in Swagger with a description of its purpose, input and responses.

| Area | Endpoint | Who |
|------|----------|-----|
| **Auth** | `POST /auth/register`, `POST /auth/login`, `POST /auth/logout` | Anyone / Anyone / Logged in |
| **Profile** | `GET /users/me`, `PUT /users/me` | Logged in |
| | `GET /users/{id}` | Organiser |
| **Events** | `GET /events` (filters: city, province, dateFrom, dateTo, status; paging), `GET /events/{id}` | Anyone |
| | `GET /events/my` | Organiser |
| | `POST /events`, `PUT /events/{id}`, `DELETE /events/{id}` (cancels) | Organiser (owner) |
| **Categories** | `GET /events/{eventId}/categories`, `GET /categories/{id}` | Anyone |
| | `POST /events/{eventId}/categories`, `PUT /categories/{id}`, `DELETE /categories/{id}` | Organiser (owner) |
| **Enrolments** | `POST /enrolments`, `GET /enrolments/me` | Participant |
| | `GET /events/{eventId}/enrolments`, `PUT /enrolments/{id}/bib` | Organiser (owner) |
| | `GET /enrolments/{id}`, `PUT /enrolments/{id}/cancel` | Participant (own) or Organiser (owner) |
| **Results** | `POST /results`, `PUT /results/{id}`, `DELETE /results/{id}` | Organiser (owner) |
| | `GET /results/me` | Participant |
| | `GET /events/{eventId}/results` | Anyone |
| | `GET /results/{id}` | Participant (own) or Organiser (owner) |
| **Health** | `GET /health` | Anyone |

Errors always use the same shape: `{ "message": "...", "errors": { "field": ["..."] } }`.

Business rules worth knowing: a participant can enrol once per category; cancelled enrolments free up their place and can be re-activated;
categories and events can have capacity limits; age limits are checked against the participant's date of birth;
bib numbers are unique within an event; a category with enrolments cannot be deleted; deleting an event cancels it (status `Cancelled`).

## Unit tests (RaceDay.Tests)

xUnit tests run the real API in memory with `WebApplicationFactory`. They cover both **success** and **failure** scenarios for:

- **User registration and login** - valid/invalid role, duplicate email, weak password, hashed password stored, wrong password, session, logout
- **Event management** - Organisers can create/update/cancel their own events; other organisers get 403
- **Role separation** - Participants rejected from Organiser endpoints (403), Organisers rejected from Participant endpoints (403), anonymous users get 401
- **Event enrolments** - a Participant can enrol and the participant/category/event link is recorded; duplicates, full categories, drafts, age limits
- Categories and results (capture, ownership, visibility of own results only)

## GitHub Actions CI/CD

`.github/workflows/dotnet.yml` restores, builds and runs every unit test on every push.

**Screenshot of a successful green build:**

*(paste your green GitHub Actions screenshot here before submitting)*

## Video

**Unlisted YouTube link:** *(paste your video link here)*

See `docs/Part2_Video_Guide.md` for a suggested running order.

## Repository structure

```
/
├── RaceDay.sln
├── RaceDay.Api/
│   ├── Controllers/     Auth, Users, Events, Categories, Enrolments, Results, Health
│   ├── Models/          Role, User, Event, Category, Enrolment, Result (match the Part 1 ERD)
│   ├── Data/            ApplicationDbContext, DbSeeder
│   ├── Dtos/            request/response objects (no password hashes leave the API)
│   ├── Common/          constants, error shape, mappers, JSON converter
│   └── Program.cs
├── RaceDay.Tests/       xUnit tests
├── docs/                Part 1 documents + Part 2 guides
└── .github/workflows/   dotnet.yml (Part 2 CI), validate-docs.yml (Part 1)
```

## AI Tool Disclosure

AI assistance was used to help generate and structure the code and documentation for this part.
All design decisions follow my Part 1 plan, and I reviewed, ran and understand the code and can explain it.
